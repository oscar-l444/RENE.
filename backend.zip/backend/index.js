const express = require("express");
const usuarioRutas = require("./rutas/rutasProductos");

const app = express();

// Aceptar datos de formularios y JSON
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Rutas
app.use("/", usuarioRutas);

const port = process.env.PORT || 3000;
app.listen(port, () => {
    console.log(`Servidor ejecutándose en https://localhost:${port}`);
});
