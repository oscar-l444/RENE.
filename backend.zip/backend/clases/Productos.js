class Productos {
    constructor(data) {
        this.id = data.id;
        this.nombre = data.nombre;  // Asignación directa de nombre
        this.precio = data.precio;  // Asignación directa de precio
        this.cantidad = data.cantidad;  // Asignación directa de cantidad
    }

    // Setters
    set id(id) {
        this._id = id;
    }

    set nombre(nombre) {
        const nombreRegex = /^[A-ZÁÉÍÓÚÑ][a-záéíóúñ']{1,}([ ][A-ZÁÉÍÓÚÑ'][a-záéíóúñ']{1,}){0,}$/;
        if (nombreRegex.test(nombre)) {
            this._nombre = nombre;
        } else {
            throw new Error("El nombre no cumple con el formato adecuado.");
        }
    }

    set cantidad(cantidad) {
        if (!isNaN(cantidad) && Number(cantidad) > 0) {
            this._cantidad = Number(cantidad); // Asegurarse de que sea un número positivo
        } else {
            throw new Error("La cantidad debe ser un número válido mayor que 0.");
        }
    }

    set precio(precio) {
        if (!isNaN(precio) && Number(precio) > 0) {
            this._precio = Number(precio); // Asegurarse de que sea un número positivo
        } else {
            throw new Error("El precio debe ser un número válido mayor que 0.");
        }
    }

    // Getters
    get id() {
        return this._id;
    }

    get nombre() {
        return this._nombre;
    }

    get cantidad() {
        return this._cantidad;
    }

    get precio() {
        return this._precio;
    }

    // Método para obtener el producto con o sin ID
    getProducto() {
        return {
            id: this._id,
            nombre: this._nombre,
            cantidad: this._cantidad,
            precio: this._precio,
        };
    }
}

module.exports = Productos;

/* 
// Ejemplo de prueba
var data = {
    id: "123",
    nombre: "Benito Juarez",
    precio: "150",
    cantidad: "50",
};

var producto1 = new Productos(data);
console.log(producto1.getProducto());
*/
