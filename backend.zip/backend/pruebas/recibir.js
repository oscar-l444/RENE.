var a=require("./variables");
var obj=require("./variables2");
var{b,c}=require("./variables2");
var b=require("./variables2").b;
console.log(a);
console.log(obj);
console.log(obj.c);
console.log(c);
console.log(b);

