var obj={
    nombre:"Fulanito",
    edad:20
}
console.log(obj);
obj.celular=4271833846;
console.log(obj);
obj.correos={
    correo1:"ejemplo@example.com",
    correo2:"ejemplo2@example.com"
}
console.log(obj.correos.correo2);
var persona={};
persona.nombre="pepeluis";
console.log(persona);