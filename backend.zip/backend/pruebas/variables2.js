var b=200;
var c=300;

module.exports={
    b,
    c
};