var a=100;
module.exports=a;