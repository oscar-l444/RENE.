var ruta=require("express").Router();
var { mostrarUsuarios, nuevoUsuario, borrarUsuario, BuscarporId } = require("../bd/usuariosBD");


ruta.get("/",async(req,res)=>{
    //res.send("Hola estas en raiz")
  const usuarios= await  mostrarUsuarios();
 // console.log(usuarios);
  res.json(usuarios);
});
ruta.get("/BuscarporId/:id",async(req,res)=>{
var usuariovalido= await BuscarporId(req.params.id)
res.json(usuariovalido);
});


ruta.get("/borrarUsuario/:id",async(req,res)=>{
  var borrado=await borrarUsuario(req.params.id)
  res.json(borrado);
});
ruta.post("/nuevoUsuario",async(req,res)=>{
  var usuarioValido=await nuevoUsuario(req.body);
  res.json(usuarioValido);
})
module.exports=ruta; 