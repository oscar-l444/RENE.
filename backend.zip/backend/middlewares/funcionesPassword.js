const crypto = require("crypto");

// Función para encriptar contraseñas
function encriptarPassword(password) {
    try {
        const salt = crypto.randomBytes(32).toString("hex"); // Generar un salt aleatorio
        const hash = crypto.scryptSync(password, salt, 64).toString("hex"); // Encriptar la contraseña
        return {
            salt,
            hash
        };
    } catch (error) {
        console.error("Error al encriptar la contraseña:", error);
        throw new Error("No se pudo encriptar la contraseña.");
    }
}

// Función para validar contraseñas
function validarPassword(password, hash, salt) {
    try {
        const hashEvaluar = crypto.scryptSync(password, salt, 64).toString("hex"); // Encriptar de nuevo para comparar
        return hashEvaluar === hash; // Comprobar si el hash coincide
    } catch (error) {
        console.error("Error al validar la contraseña:", error);
        return false;
    }
}

module.exports = {
    encriptarPassword,
    validarPassword
};
