const admin = require("firebase-admin");
const keys = require("../keys.json");

// Inicializa la aplicación de Firebase con las credenciales de Firebase
admin.initializeApp({
    credential: admin.credential.cert(keys),
});

const db = admin.firestore();

// Referencia a las colecciones de Firestore
const usuarios = db.collection("usuariosBD");
const productos = db.collection("productosBD");

module.exports = {
    usuarios,
    productos,
};

