const admin = require("firebase-admin");
const fs = require("fs");

let keys;
try {
    // Intenta cargar las credenciales desde el archivo keys.json
    keys = require("../keys.json");
} catch (error) {
    console.error("No se encontró el archivo keys.json o está mal formado", error);
    process.exit(1); // Salir del proceso si no hay credenciales válidas
}

// Inicializa la aplicación de Firebase con las credenciales de Firebase
try {
    admin.initializeApp({
        credential: admin.credential.cert(keys),
    });
    console.log("Firebase inicializado correctamente");
} catch (error) {
    console.error("Error al inicializar Firebase", error);
    process.exit(1); // Salir del proceso si la inicialización falla
}

const db = admin.firestore();

// Referencia a las colecciones de Firestore
const usuarios = db.collection("usuariosBD");
const productos = db.collection("productosBD");

module.exports = {
    usuarios,
    productos,
};

// Solo para pruebas: Puedes descomentar la línea a continuación si quieres verificar los documentos
// usuarios.get().then(snapshot => console.log(snapshot.docs.map(doc => doc.data()))).catch(err => console.log(err));
