const usuariosBD = require("./conexion").usuarios; // Cambiar productosBD a usuariosBD
const Usuario = require("../clases/Productos"); // Asegúrate de que este es el nombre correcto de la clase
const { encriptarPassword, validarPassword } = require("../middlewares/funcionesPassword");

// Función para validar los datos del usuario
function validardatos(usuario) {
    return usuario.nombre !== undefined && usuario.usuario !== undefined && usuario.password !== undefined;
}

// Función para mostrar todos los usuarios
async function mostrarUsuarios() {
    const usuariosSnapshot = await usuariosBD.get(); // Cambiar productosBD a usuariosBD
    const usuariosValidos = [];

    usuariosSnapshot.forEach(usuarioDoc => {
        const usuario = new Usuario({ id: usuarioDoc.id, ...usuarioDoc.data() });
        const usuarioData = usuario.getUsuario;

        if (validardatos(usuarioData)) {
            usuariosValidos.push(usuarioData); // Añadir solo los usuarios válidos
        }
    });

    return usuariosValidos;
}

// Función para buscar usuario por ID
async function BuscarporId(id) {
    const usuarioDoc = await usuariosBD.doc(id).get();
    if (!usuarioDoc.exists) {
        return { error: true }; // Retornar error si el usuario no existe
    }

    const usuario = new Usuario({ id: usuarioDoc.id, ...usuarioDoc.data() });
    if (validardatos(usuario.getUsuario)) {
        return usuario.getUsuario;
    }

    return { error: true }; // Retornar error si los datos del usuario no son válidos
}

// Función para crear un nuevo usuario
async function nuevoUsuario(data) {
    const { salt, hash } = encriptarPassword(data.password);
    data.password = hash;
    data.salt = salt;
    data.tipoUsuario = "usuario";

    const usuario = new Usuario(data);
    if (validardatos(usuario.getUsuario)) {
        await usuariosBD.doc().set(usuario.getUsuario);
        return true; // Usuario creado correctamente
    }

    return false; // Datos no válidos, no se crea el usuario
}

// Función para borrar un usuario por ID
async function borrarUsuario(id) {
    const usuario = await BuscarporId(id);
    if (usuario.error) {
        return false; // El usuario no existe o los datos no son válidos
    }

    await usuariosBD.doc(id).delete();
    return true; // Usuario borrado correctamente
}

// Exportar las funciones
module.exports = {
    mostrarUsuarios,
    nuevoUsuario,
    borrarUsuario,
    BuscarporId,
};
